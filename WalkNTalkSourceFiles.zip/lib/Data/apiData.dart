String weatherAPIURL = "https://api.data.gov.sg/v1/environment/24-hour-weather-forecast";
String googleMapsAPI = "AIzaSyAv8UrBikmhBU4Gz-nGDGW9-beFeMkH6Vk";
String geminiAPIKey = "AIzaSyDfMEIhte-lSc0NjEF-qwlyrjpzclgJaEo";